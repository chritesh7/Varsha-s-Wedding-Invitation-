(function(){
  var body=document.body;
  body.classList.add('locked');

  var doors=document.getElementById('doors');
  var btn=document.getElementById('open');
  var reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function petals(){
    var colors=[
      'linear-gradient(135deg,#F3D9A0,#CFA85A)',
      'linear-gradient(135deg,#F6E2B8,#D8B26A)',
      'linear-gradient(135deg,#E0508F,#8E2243)'
    ];
    var made=[];
    for(var i=0;i<30;i++){
      var p=document.createElement('span');
      p.className='petal';
      var size=10+Math.random()*9;
      p.style.width=size+'px';
      p.style.height=size*1.2+'px';
      p.style.left=(Math.random()*100)+'vw';
      p.style.background=colors[Math.floor(Math.random()*colors.length)];
      p.style.setProperty('--dx',((Math.random()-.5)*240)+'px');
      p.style.setProperty('--rot',(360+Math.random()*540)+'deg');
      p.style.animationDuration=(5+Math.random()*4)+'s';
      p.style.animationDelay=(.5+Math.random()*3)+'s';
      document.body.appendChild(p);
      made.push(p);
    }
    setTimeout(function(){made.forEach(function(p){p.remove();});},13000);
  }

  /* ───────── Music: the wedding song from the very start (loud, looped); soft synth is the fallback ───────── */
  var Music=(function(){
    var ctx,master,volNode,userVol=1,rev,delay,timer,nextT=0,pi=0,ni=0,enabled=false,synthReady=false;
    var songBuf=null,songFailed=false,songTimer=null,songNext=0,loading=false,waiters=[];
    var FI=.3,FO=1.2,OV=.7,SONG_GAIN=1.25;
    var SA=293.66,BEAT=.9;
    var A=[[1,1],[5/4,1],[3/2,1.5],[5/3,.5],[3/2,1],[5/4,1],[9/8,1],[1,2]];
    var B=[[5/4,.5],[3/2,.5],[5/3,1],[2,1.5],[5/3,.5],[3/2,1],[5/4,1],[9/8,.5],[1,1.5]];
    var C=[[3/2,1],[5/3,1],[2,2],[9/4,1],[2,1],[5/3,1],[3/2,2]];
    var D=[[5/4,1],[3/2,.5],[5/4,.5],[9/8,1],[1,1],[5/6,1],[1,3]];
    var SEQ=[A,B,A,C,D];

    function init(){
      var AC=window.AudioContext||window.webkitAudioContext;
      if(!AC)return false;
      try{ctx=new AC({sampleRate:32000});}
      catch(e){try{ctx=new AC();}catch(e2){return false;}}
      /* limiter: lets the master gain run loud without clipping */
      var lim=ctx.createDynamicsCompressor();
      lim.threshold.value=-2;lim.knee.value=0;lim.ratio.value=20;
      lim.attack.value=.002;lim.release.value=.08;
      master=ctx.createGain();master.gain.value=0;
      volNode=ctx.createGain();volNode.gain.value=userVol;
      master.connect(lim);lim.connect(volNode);volNode.connect(ctx.destination);
      return true;
    }

    function loadSong(cb){
      if(songBuf||songFailed){cb();return;}
      waiters.push(cb);
      if(loading)return;
      loading=true;
      var done=false;
      function finish(){loading=false;var w=waiters;waiters=[];w.forEach(function(f){f();});}
      function ok(b){if(done)return;done=true;songBuf=b;finish();}
      function fail(){if(done)return;done=true;songFailed=true;finish();}
      try{
        fetch('assets/song.mp3').then(function(r){if(!r.ok)throw 0;return r.arrayBuffer();})
          .then(function(buf){var p=ctx.decodeAudioData(buf,ok,fail);if(p&&p.catch)p.catch(fail);})
          .catch(fail);
      }catch(e){fail();}
    }
    function songCycle(t){
      var seg=songBuf.duration;
      var s=ctx.createBufferSource();s.buffer=songBuf;
      var g=ctx.createGain();
      g.gain.setValueAtTime(.0001,t);
      g.gain.linearRampToValueAtTime(1,t+FI);
      g.gain.setValueAtTime(1,t+seg-FO);
      g.gain.linearRampToValueAtTime(.0001,t+seg);
      s.connect(g);g.connect(master);s.start(t);
      songNext=t+seg-OV;
    }
    function songTick(){while(songNext<ctx.currentTime+2)songCycle(songNext);}

    function initSynth(){
      if(synthReady)return;synthReady=true;
      var len=Math.floor(ctx.sampleRate*2.6),buf=ctx.createBuffer(2,len,ctx.sampleRate);
      for(var c=0;c<2;c++){var d=buf.getChannelData(c);for(var i=0;i<len;i++)d[i]=(Math.random()*2-1)*Math.pow(1-i/len,2.6);}
      rev=ctx.createConvolver();rev.buffer=buf;
      var revG=ctx.createGain();revG.gain.value=.5;rev.connect(revG);revG.connect(master);
      delay=ctx.createDelay(1);delay.delayTime.value=BEAT*.75;
      var fb=ctx.createGain();fb.gain.value=.28;delay.connect(fb);fb.connect(delay);
      var dg=ctx.createGain();dg.gain.value=.32;delay.connect(dg);dg.connect(rev);dg.connect(master);
      var g=ctx.createGain();g.gain.value=.15;g.connect(master);
      var f=ctx.createBiquadFilter();f.type='lowpass';f.frequency.value=900;f.connect(g);
      [[SA/2,'triangle',0],[SA/2,'sine',4],[SA*.75,'triangle',-3],[SA,'sine',2]].forEach(function(o){
        var os=ctx.createOscillator();os.type=o[1];os.frequency.value=o[0];os.detune.value=o[2];os.connect(f);os.start();
      });
      var l=ctx.createOscillator(),lg=ctx.createGain();
      l.frequency.value=.12;lg.gain.value=.05;l.connect(lg);lg.connect(g.gain);l.start();
    }
    function pluck(freq,t,dur){
      var end=t+dur*1.6+.8;
      var g=ctx.createGain();
      g.gain.setValueAtTime(.0001,t);
      g.gain.exponentialRampToValueAtTime(.32,t+.012);
      g.gain.exponentialRampToValueAtTime(.0008,end);
      var f=ctx.createBiquadFilter();f.type='lowpass';
      f.frequency.setValueAtTime(3600,t);
      f.frequency.exponentialRampToValueAtTime(700,t+.5);
      f.connect(g);
      [['triangle',0,1],['sawtooth',5,.28],['sine',0,.14]].forEach(function(s,i){
        var o=ctx.createOscillator(),og=ctx.createGain();
        o.type=s[0];o.frequency.value=i===2?freq*2:freq;o.detune.value=s[1];
        og.gain.value=s[2];o.connect(og);og.connect(f);o.start(t);o.stop(end);
      });
      g.connect(master);
      var sd=ctx.createGain();sd.gain.value=.6;g.connect(sd);sd.connect(delay);sd.connect(rev);
    }
    function tick(){
      while(nextT<ctx.currentTime+.4){
        var ph=SEQ[pi];
        if(ni<ph.length){var n=ph[ni];pluck(SA*n[0],nextT,n[1]*BEAT);nextT+=n[1]*BEAT;ni++;}
        else{ni=0;pi=(pi+1)%SEQ.length;nextT+=BEAT*2;}
      }
    }

    function begin(){
      if(!enabled)return;
      master.gain.cancelScheduledValues(ctx.currentTime);
      if(songBuf){
        master.gain.setTargetAtTime(SONG_GAIN,ctx.currentTime,.05);
        if(!songTimer){songNext=ctx.currentTime+.05;songTick();songTimer=setInterval(songTick,500);}
      }else{
        initSynth();
        master.gain.setTargetAtTime(.55,ctx.currentTime,1.2);
        nextT=Math.max(nextT,ctx.currentTime+.6);
        if(!timer)timer=setInterval(tick,100);
      }
    }

    document.addEventListener('visibilitychange',function(){
      if(!ctx)return;
      if(document.hidden)ctx.suspend();else if(enabled)ctx.resume();
    });

    return {
      preload:function(){
        if(!ctx&&!init())return;
        loadSong(function(){});
      },
      start:function(){
        if(!ctx&&!init())return false;
        ctx.resume();
        enabled=true;
        if(songBuf||songFailed)begin();else loadSong(begin);
        return true;
      },
      stop:function(){
        if(!ctx)return;
        enabled=false;
        master.gain.cancelScheduledValues(ctx.currentTime);
        master.gain.setTargetAtTime(0,ctx.currentTime,.2);
        setTimeout(function(){if(!enabled)ctx.suspend();},900);
      },
      setVol:function(v){userVol=v;if(volNode)volNode.gain.setTargetAtTime(v,ctx.currentTime,.03);},
      on:function(){return enabled;}
    };
  })();
  /* decode the song in the background so it starts instantly on tap */
  setTimeout(function(){Music.preload();},400);

  var musicBtn=document.getElementById('music');
  function setMusicUI(on){
    musicBtn.classList.toggle('off',!on);
  }
  var hideT;
  function showVol(show){
    volWrap.hidden=!show;
    musicBtn.setAttribute('aria-expanded',show?'true':'false');
    clearTimeout(hideT);
    if(show)hideT=setTimeout(function(){showVol(false);},4000);
  }
  musicBtn.addEventListener('click',function(e){
    e.stopPropagation();
    showVol(volWrap.hidden);
  });
  document.addEventListener('click',function(e){
    if(!volWrap.hidden&&!volWrap.contains(e.target))showVol(false);
  });

  var volEl=document.getElementById('vol'),volWrap=document.getElementById('volWrap');
  function applyVol(){
    var v=volEl.value/100;
    volEl.style.setProperty('--p',volEl.value+'%');
    Music.setVol(v*v);
    musicBtn.classList.toggle('off',!Music.on()||v===0);
  }
  volEl.addEventListener('input',function(){
    clearTimeout(hideT);hideT=setTimeout(function(){showVol(false);},4000);
    var v=volEl.value/100;
    if(v>0&&!Music.on()){setMusicUI(Music.start());}
    applyVol();
  });

  var nav=document.getElementById('nav');
  var links=[].slice.call(nav.querySelectorAll('a'));
  function setOn(id){
    links.forEach(function(a){
      var on=a.getAttribute('data-s')===id;
      a.classList.toggle('on',on);
      if(on){a.setAttribute('aria-current','true');
        var ul=a.parentNode.parentNode;
        if(ul.scrollWidth>ul.clientWidth)ul.scrollLeft=a.offsetLeft-ul.clientWidth/2+a.offsetWidth/2;
      }else a.removeAttribute('aria-current');
    });
  }
  if('IntersectionObserver' in window){
    var io=new IntersectionObserver(function(es){
      es.forEach(function(e){if(e.isIntersecting)setOn(e.target.id);});
    },{rootMargin:'-45% 0px -50% 0px'});
    links.forEach(function(a){var t=document.getElementById(a.getAttribute('data-s'));if(t)io.observe(t);});
  }
  setOn('home');

  function openInvite(){
    if(body.classList.contains('opened'))return;
    body.classList.add('opened');
    if(Music.start()){musicBtn.hidden=false;setMusicUI(true);applyVol();}
    if(!reduce)petals();
    setTimeout(function(){
      nav.hidden=false;
      doors.hidden=true;
      body.classList.remove('locked');
      window.scrollTo(0,0);
    },reduce?350:2300);
  }
  btn.addEventListener('click',openInvite);

  var cd=document.getElementById('countdown');
  var target=new Date(cd.getAttribute('data-target')).getTime();
  var eD=document.getElementById('cdD'),eH=document.getElementById('cdH'),eM=document.getElementById('cdM'),eS=document.getElementById('cdS');
  var eT=document.getElementById('cdTitle'),eN=document.getElementById('cdNote');
  function pad(n){return n<10?'0'+n:''+n;}
  function tickCd(){
    var left=target-Date.now();
    if(left<=0){
      cd.classList.add('cd-done');
      eT.textContent='शुभ विवाह';
      eN.textContent=(Date.now()-target<864e5)?'आज है विवाह का शुभ दिन। आपके आशीर्वाद के लिए धन्यवाद।':'आपके स्नेह और आशीर्वाद के लिए हृदय से आभार।';
      return false;
    }
    var t=Math.floor(left/1000);
    eD.textContent=Math.floor(t/86400);
    eH.textContent=pad(Math.floor(t%86400/3600));
    eM.textContent=pad(Math.floor(t%3600/60));
    eS.textContent=pad(t%60);
    eN.textContent='बारात स्वागत: 20 अक्टूबर 2026, रात्रि 8:00 बजे';
    return true;
  }
  if(tickCd()){
    var cdTimer=setInterval(function(){if(!tickCd())clearInterval(cdTimer);},1000);
  }
})();
